import { ArrowLeft, Plus, Activity, Dumbbell, Brain, Heart, Droplet } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ChallengesPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-rose-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <Link href="/" className="mr-4">
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Challenges</h1>
          </div>
          <Button className="bg-rose-600 hover:bg-rose-700">
            <Plus className="h-4 w-4 mr-2" />
            New Challenge
          </Button>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <Tabs defaultValue="active" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-rose-50">
            <TabsTrigger value="active" className="data-[state=active]:bg-white">
              Active
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-white">
              Completed
            </TabsTrigger>
            <TabsTrigger value="discover" className="data-[state=active]:bg-white">
              Discover
            </TabsTrigger>
          </TabsList>

          <TabsContent value="active" className="mt-4 space-y-4">
            <Card className="overflow-hidden border-rose-100">
              <div className="h-3 bg-rose-500" />
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="bg-rose-100 p-2 rounded-lg text-rose-600">
                      <Activity className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">75 Medium Challenge</h3>
                      <p className="text-sm text-gray-500">Day 23 of 75</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="text-xs">
                    View
                  </Button>
                </div>
                <Progress value={30} className="h-2 bg-rose-100" indicatorClassName="bg-rose-500" />
                <div className="grid grid-cols-4 gap-2 mt-4">
                  <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-rose-100">
                    <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 mb-1">
                      <Dumbbell className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-gray-600">Workout</span>
                    <span className="text-xs font-medium text-rose-600">Done</span>
                  </div>
                  <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-rose-100">
                    <div className="w-8 h-8 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 mb-1">
                      <Droplet className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-gray-600">Water</span>
                    <span className="text-xs font-medium text-rose-600">Done</span>
                  </div>
                  <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-gray-200">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mb-1">
                      <Brain className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-gray-600">Reading</span>
                    <span className="text-xs text-gray-400">30 min</span>
                  </div>
                  <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-gray-200">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mb-1">
                      <Heart className="h-4 w-4" />
                    </div>
                    <span className="text-xs text-gray-600">Self-care</span>
                    <span className="text-xs text-gray-400">Pending</span>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex justify-between">
                <Button variant="outline" size="sm" className="text-xs">
                  Check-in Photo
                </Button>
                <Button size="sm" className="text-xs bg-rose-600 hover:bg-rose-700">
                  Complete Today
                </Button>
              </CardFooter>
            </Card>

            <Card className="overflow-hidden border-rose-100">
              <div className="h-3 bg-purple-500" />
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <div className="bg-purple-100 p-2 rounded-lg text-purple-600">
                      <Brain className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">Mindfulness Journey</h3>
                      <p className="text-sm text-gray-500">Day 12 of 30</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="text-xs">
                    View
                  </Button>
                </div>
                <Progress value={40} className="h-2 bg-purple-100" indicatorClassName="bg-purple-500" />
                <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-700">Today's focus: Breath awareness meditation for 15 minutes</p>
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <Button size="sm" className="w-full text-xs bg-purple-600 hover:bg-purple-700">
                  Start Today's Session
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="mt-4">
            <div className="text-center py-8 text-gray-500">
              <Activity className="h-12 w-12 mx-auto mb-2 text-gray-400" />
              <h3 className="font-medium text-gray-700">Completed Challenges</h3>
              <p className="text-sm">Your completed challenges will appear here</p>
            </div>
          </TabsContent>

          <TabsContent value="discover" className="mt-4">
            <div className="grid gap-4">
              <Card className="overflow-hidden border-rose-100">
                <div className="h-32 bg-gradient-to-r from-rose-400 to-rose-600 flex items-center justify-center">
                  <Activity className="h-12 w-12 text-white" />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900">75 Hard Challenge</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    The ultimate mental toughness program. Two workouts daily, strict diet, daily reading, and more for
                    75 days.
                  </p>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Button size="sm" className="w-full text-xs bg-rose-600 hover:bg-rose-700">
                    Start Challenge
                  </Button>
                </CardFooter>
              </Card>

              <Card className="overflow-hidden border-rose-100">
                <div className="h-32 bg-gradient-to-r from-purple-400 to-purple-600 flex items-center justify-center">
                  <Heart className="h-12 w-12 text-white" />
                </div>
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900">30-Day Skincare Transformation</h3>
                  <p className="text-sm text-gray-600 mt-1">
                    Consistent morning and evening skincare routines with weekly treatments and photo tracking.
                  </p>
                </CardContent>
                <CardFooter className="p-4 pt-0">
                  <Button size="sm" className="w-full text-xs bg-purple-600 hover:bg-purple-700">
                    Start Challenge
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <nav className="sticky bottom-0 border-t bg-white">
        <div className="container flex items-center justify-between px-4 py-2">
          <Link href="/" className="flex flex-col items-center p-2 text-gray-500">
            <Home className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/calendar" className="flex flex-col items-center p-2 text-gray-500">
            <Calendar className="h-5 w-5" />
            <span className="text-xs">Calendar</span>
          </Link>
          <Link href="/assistant" className="flex flex-col items-center p-2 text-gray-500">
            <Brain className="h-5 w-5" />
            <span className="text-xs">Soma AI</span>
          </Link>
          <Link href="/challenges" className="flex flex-col items-center p-2 text-rose-600">
            <Activity className="h-5 w-5" />
            <span className="text-xs">Challenges</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center p-2 text-gray-500">
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

function Home(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}

function Calendar(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
      <line x1="16" x2="16" y1="2" y2="6" />
      <line x1="8" x2="8" y1="2" y2="6" />
      <line x1="3" x2="21" y1="10" y2="10" />
    </svg>
  )
}

function User(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="8" r="5" />
      <path d="M20 21a8 8 0 1 0-16 0" />
    </svg>
  )
}
