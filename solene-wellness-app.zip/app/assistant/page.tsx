import {
  ArrowLeft,
  Send,
  Mic,
  Brain,
  Calendar,
  Clock,
  Sparkles,
  BookOpen,
  AlarmClock,
  CheckCircle,
  MessageSquare,
  Volume2,
} from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"

export default function AssistantPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center h-16 px-4">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </Link>
          <div className="flex items-center">
            <Avatar className="h-8 w-8 mr-2">
              <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Soma AI" />
              <AvatarFallback className="bg-purple-200 text-purple-900">
                <Brain className="h-4 w-4" />
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-lg font-semibold text-gray-900">Soma AI Assistant</h1>
              <p className="text-xs text-gray-500">Your personal wellness guide</p>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <Tabs defaultValue="chat" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-purple-50">
            <TabsTrigger value="chat" className="data-[state=active]:bg-white">
              Chat
            </TabsTrigger>
            <TabsTrigger value="schedule" className="data-[state=active]:bg-white">
              Schedule
            </TabsTrigger>
            <TabsTrigger value="study" className="data-[state=active]:bg-white">
              Study
            </TabsTrigger>
            <TabsTrigger value="morning" className="data-[state=active]:bg-white">
              Morning Call
            </TabsTrigger>
          </TabsList>

          <TabsContent value="chat" className="mt-4">
            <div className="space-y-4 mb-20">
              <div className="flex justify-center mb-6">
                <div className="bg-gray-100 text-gray-500 text-xs px-3 py-1 rounded-full">Today</div>
              </div>

              <div className="flex items-start gap-3 max-w-md">
                <Avatar className="mt-1">
                  <AvatarFallback className="bg-purple-200 text-purple-900">
                    <Brain className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-white rounded-lg rounded-tl-none p-3 shadow-sm">
                  <p className="text-gray-800">
                    Good morning, Jane! Based on your follicular phase and today's schedule, I've prepared some
                    recommendations:
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 max-w-md ml-auto">
                <div className="bg-purple-100 rounded-lg rounded-tr-none p-3">
                  <p className="text-gray-800">What should I focus on today?</p>
                </div>
                <Avatar className="mt-1">
                  <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                  <AvatarFallback className="bg-purple-200">JD</AvatarFallback>
                </Avatar>
              </div>

              <div className="flex items-start gap-3 max-w-md">
                <Avatar className="mt-1">
                  <AvatarFallback className="bg-purple-200 text-purple-900">
                    <Brain className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="space-y-3">
                  <div className="bg-white rounded-lg rounded-tl-none p-3 shadow-sm">
                    <p className="text-gray-800">
                      Today is ideal for creative work and learning! Your energy is high during this phase. I recommend:
                    </p>
                  </div>

                  <Card className="border-purple-100">
                    <CardContent className="p-3 space-y-3">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-purple-800" />
                        <div>
                          <h3 className="text-sm font-medium">Biology Study Session</h3>
                          <p className="text-xs text-gray-500">2:00 PM - 4:00 PM</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4 text-purple-800" />
                        <div>
                          <h3 className="text-sm font-medium">Evening Skincare Ritual</h3>
                          <p className="text-xs text-gray-500">7:00 PM</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Sparkles className="h-4 w-4 text-purple-800" />
                        <div>
                          <h3 className="text-sm font-medium">Journal Reflection</h3>
                          <p className="text-xs text-gray-500">9:00 PM - Reflect on today's achievements</p>
                        </div>
                      </div>
                      <Button size="sm" className="w-full bg-purple-800 hover:bg-purple-900 text-xs">
                        Add to Calendar
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div className="flex items-start gap-3 max-w-md ml-auto">
                <div className="bg-purple-100 rounded-lg rounded-tr-none p-3">
                  <p className="text-gray-800">Can you help me stay accountable for my study session today?</p>
                </div>
                <Avatar className="mt-1">
                  <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                  <AvatarFallback className="bg-purple-200">JD</AvatarFallback>
                </Avatar>
              </div>

              <div className="flex items-start gap-3 max-w-md">
                <Avatar className="mt-1">
                  <AvatarFallback className="bg-purple-200 text-purple-900">
                    <Brain className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-white rounded-lg rounded-tl-none p-3 shadow-sm">
                  <p className="text-gray-800">
                    I'll send you check-in reminders during your study session from 2-4 PM. Would you like me to:
                  </p>
                  <div className="mt-2 space-y-2">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-purple-800" />
                      <p className="text-sm">Send you a reminder to take breaks every 25 minutes</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-purple-800" />
                      <p className="text-sm">Ask you about your progress at the halfway point</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="h-4 w-4 text-purple-800" />
                      <p className="text-sm">Send a summary of what you've accomplished at the end</p>
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                      Yes, please
                    </Button>
                    <Button size="sm" variant="outline">
                      Customize
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="schedule" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-lg font-medium">Personalized Schedule</h2>
                <Badge className="bg-purple-800">Follicular Phase</Badge>
              </div>

              <Card className="border-purple-100">
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900 mb-3">Today's Optimal Schedule</h3>

                  <div className="space-y-3">
                    <div className="flex items-start gap-3 border-l-2 border-purple-800 pl-3">
                      <div className="text-right min-w-[60px]">
                        <span className="text-sm font-medium">8:00 AM</span>
                      </div>
                      <div className="bg-purple-50 p-2 rounded-md flex-1">
                        <div className="flex items-center">
                          <AlarmClock className="h-4 w-4 text-purple-800 mr-2" />
                          <span className="font-medium">Morning Routine</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">Hydration, light stretching, breakfast</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 border-l-2 border-gray-200 pl-3">
                      <div className="text-right min-w-[60px]">
                        <span className="text-sm font-medium">10:00 AM</span>
                      </div>
                      <div className="bg-purple-50 p-2 rounded-md flex-1">
                        <div className="flex items-center">
                          <Brain className="h-4 w-4 text-purple-800 mr-2" />
                          <span className="font-medium">Creative Work</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">High energy time - ideal for complex tasks</p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 border-l-2 border-gray-200 pl-3">
                      <div className="text-right min-w-[60px]">
                        <span className="text-sm font-medium">2:00 PM</span>
                      </div>
                      <div className="bg-purple-50 p-2 rounded-md flex-1">
                        <div className="flex items-center">
                          <BookOpen className="h-4 w-4 text-purple-800 mr-2" />
                          <span className="font-medium">Biology Study Session</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">Focus on chapters 7-9 for upcoming exam</p>
                        <div className="mt-2">
                          <Button size="sm" className="text-xs h-7 bg-purple-800 hover:bg-purple-900">
                            Start Session
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="px-4 py-3 bg-gray-50 flex justify-between">
                  <Button variant="outline" size="sm">
                    View Full Week
                  </Button>
                  <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                    <Calendar className="h-4 w-4 mr-2" />
                    Optimize Schedule
                  </Button>
                </CardFooter>
              </Card>

              <Card className="border-purple-100">
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900 mb-2">Schedule Insights</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-purple-800"></div>
                      <p className="text-sm">Your energy peaks between 9 AM - 12 PM during this phase</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-purple-800"></div>
                      <p className="text-sm">Ideal time for learning new concepts: 2 PM - 4 PM</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-purple-800"></div>
                      <p className="text-sm">Schedule rest period at 4:30 PM to maintain energy</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="study" className="mt-4">
            <div className="space-y-4">
              <Card className="border-purple-100">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium text-gray-900">Smart Study Plan</h3>
                    <Badge className="bg-green-600">Biology Exam in 7 days</Badge>
                  </div>

                  <div className="space-y-3">
                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <BookOpen className="h-4 w-4 text-purple-800 mr-2" />
                          <span className="font-medium">Today: Chapters 7-9</span>
                        </div>
                        <Badge className="bg-purple-800">2 hours</Badge>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Focus on cellular respiration and photosynthesis</p>
                      <div className="mt-2 flex gap-2">
                        <Button size="sm" className="text-xs h-7 bg-purple-800 hover:bg-purple-900">
                          Start Now
                        </Button>
                        <Button size="sm" variant="outline" className="text-xs h-7">
                          Resources
                        </Button>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <BookOpen className="h-4 w-4 text-gray-500 mr-2" />
                          <span className="font-medium text-gray-700">Tomorrow: Chapters 10-11</span>
                        </div>
                        <Badge variant="outline">1.5 hours</Badge>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Genetics and heredity principles</p>
                    </div>

                    <div className="bg-gray-50 p-3 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <BookOpen className="h-4 w-4 text-gray-500 mr-2" />
                          <span className="font-medium text-gray-700">Wednesday: Review Session</span>
                        </div>
                        <Badge variant="outline">1 hour</Badge>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Practice questions and concept review</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="px-4 py-3 bg-gray-50">
                  <Button className="w-full bg-purple-800 hover:bg-purple-900">
                    <Brain className="h-4 w-4 mr-2" />
                    Optimize Study Plan
                  </Button>
                </CardFooter>
              </Card>

              <Card className="border-purple-100">
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900 mb-3">Study Techniques</h3>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Pomodoro Technique</p>
                        <p className="text-xs text-gray-600">25 min focus + 5 min break (recommended for today)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Active Recall</p>
                        <p className="text-xs text-gray-600">Test yourself on key concepts after each section</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium">Spaced Repetition</p>
                        <p className="text-xs text-gray-600">Review material at increasing intervals</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="morning" className="mt-4">
            <div className="space-y-4">
              <Card className="border-purple-100 overflow-hidden">
                <div className="bg-gradient-to-r from-purple-700 to-purple-900 p-4 text-white">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-medium">Morning Motivation Call</h3>
                    <Badge className="bg-white/20 text-white">7:30 AM</Badge>
                  </div>
                  <p className="text-sm text-white/80">Start your day with intention and clarity</p>
                </div>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <Volume2 className="h-5 w-5 text-purple-800" />
                      <span className="font-medium">Voice Interaction</span>
                    </div>
                    <Badge variant="outline" className="text-purple-800 border-purple-800">
                      5-10 minutes
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div className="bg-purple-50 p-3 rounded-md">
                      <p className="text-sm font-medium">Today's Morning Call will include:</p>
                      <ul className="mt-2 space-y-2 text-sm">
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5 flex-shrink-0" />
                          <span>Daily schedule overview and priorities</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5 flex-shrink-0" />
                          <span>Personalized affirmations aligned with your goals</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5 flex-shrink-0" />
                          <span>Interactive questions to set your intentions</span>
                        </li>
                        <li className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-purple-800 mt-0.5 flex-shrink-0" />
                          <span>Cycle-aware wellness tips for today</span>
                        </li>
                      </ul>
                    </div>

                    <div className="flex gap-2">
                      <Button className="flex-1 bg-purple-800 hover:bg-purple-900">
                        <Volume2 className="h-4 w-4 mr-2" />
                        Start Morning Call
                      </Button>
                      <Button variant="outline" className="flex-1">
                        <Calendar className="h-4 w-4 mr-2" />
                        Schedule Call
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-100">
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900 mb-3">Accountability Features</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg text-purple-800">
                        <MessageSquare className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">AI Accountability Dialogue</h4>
                        <p className="text-xs text-gray-600 mt-1">
                          Soma will check in with you throughout the day to help you stay on track with your goals
                        </p>
                        <div className="mt-2">
                          <Button size="sm" variant="outline" className="text-xs">
                            Configure Check-ins
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg text-purple-800">
                        <AlarmClock className="h-5 w-5" />
                      </div>
                      <div>
                        <h4 className="text-sm font-medium">Gentle Reminders</h4>
                        <p className="text-xs text-gray-600 mt-1">
                          Receive supportive notifications to help you maintain your routines
                        </p>
                        <div className="mt-2">
                          <Button size="sm" variant="outline" className="text-xs">
                            Manage Reminders
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>

      <div className="sticky bottom-0 bg-white border-t p-4">
        <div className="container flex items-center gap-2">
          <Button variant="outline" size="icon" className="rounded-full flex-shrink-0">
            <Mic className="h-5 w-5 text-gray-600" />
          </Button>
          <Input
            placeholder="Ask Soma anything..."
            className="rounded-full border-gray-300 focus-visible:ring-purple-800"
          />
          <Button size="icon" className="rounded-full bg-purple-800 hover:bg-purple-900 flex-shrink-0">
            <Send className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </div>
  )
}
