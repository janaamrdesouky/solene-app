import { ArrowLeft, Search, BookOpen, Star, Plus, BookMarked, BookText, Quote, Download, Brain } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

export default function BookshelfPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <Link href="/" className="mr-4">
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Bookshelf</h1>
          </div>
          <Button className="bg-purple-800 hover:bg-purple-900">
            <Plus className="h-4 w-4 mr-2" />
            Add Book
          </Button>
        </div>
      </header>

      <div className="container px-4 py-4">
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search books, quotes, or topics..."
            className="pl-10 bg-white border-gray-200 focus-visible:ring-purple-800"
          />
        </div>
      </div>

      <main className="flex-1 container px-4 pb-6">
        <Tabs defaultValue="reading" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-purple-50">
            <TabsTrigger value="reading" className="data-[state=active]:bg-white">
              Reading
            </TabsTrigger>
            <TabsTrigger value="completed" className="data-[state=active]:bg-white">
              Completed
            </TabsTrigger>
            <TabsTrigger value="quotes" className="data-[state=active]:bg-white">
              Quotes
            </TabsTrigger>
            <TabsTrigger value="recommended" className="data-[state=active]:bg-white">
              Recommended
            </TabsTrigger>
          </TabsList>

          <TabsContent value="reading" className="mt-4 space-y-4">
            <Card className="border-purple-100 overflow-hidden">
              <div className="flex p-4">
                <div className="w-20 h-28 bg-gray-100 rounded-md flex-shrink-0 mr-4 overflow-hidden">
                  <img
                    src="/placeholder.svg?height=112&width=80"
                    alt="Book cover"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">Atomic Habits</h3>
                      <p className="text-sm text-gray-500">James Clear</p>
                    </div>
                    <Badge className="bg-purple-800">Currently Reading</Badge>
                  </div>
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Progress: 42%</span>
                      <span className="text-gray-600">Page 86 of 204</span>
                    </div>
                    <Progress value={42} className="h-2 mt-1 bg-gray-100" indicatorClassName="bg-purple-700" />
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Continue Reading
                    </Button>
                    <Button size="sm" variant="outline">
                      <Quote className="h-4 w-4 mr-2" />
                      View Highlights
                    </Button>
                  </div>
                </div>
              </div>
            </Card>

            <Card className="border-purple-100 overflow-hidden">
              <div className="flex p-4">
                <div className="w-20 h-28 bg-gray-100 rounded-md flex-shrink-0 mr-4 overflow-hidden">
                  <img
                    src="/placeholder.svg?height=112&width=80"
                    alt="Book cover"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-gray-900">The Power of Now</h3>
                      <p className="text-sm text-gray-500">Eckhart Tolle</p>
                    </div>
                    <Badge variant="outline" className="text-purple-800 border-purple-800">
                      Just Started
                    </Badge>
                  </div>
                  <div className="mt-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Progress: 8%</span>
                      <span className="text-gray-600">Page 12 of 152</span>
                    </div>
                    <Progress value={8} className="h-2 mt-1 bg-gray-100" indicatorClassName="bg-purple-700" />
                  </div>
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Continue Reading
                    </Button>
                    <Button size="sm" variant="outline">
                      <Quote className="h-4 w-4 mr-2" />
                      View Highlights
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="mt-4 space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card className="border-purple-100">
                <CardContent className="p-3">
                  <div className="w-full h-32 bg-gray-100 rounded-md mb-3 overflow-hidden">
                    <img
                      src="/placeholder.svg?height=128&width=180"
                      alt="Book cover"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-medium text-gray-900 text-sm">Thinking, Fast and Slow</h3>
                  <p className="text-xs text-gray-500">Daniel Kahneman</p>
                  <div className="flex items-center mt-1">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-3 w-3 ${star <= 4 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500 ml-1">4.0</span>
                  </div>
                </CardContent>
                <CardFooter className="p-3 pt-0">
                  <Button size="sm" variant="outline" className="w-full text-xs">
                    <Quote className="h-3 w-3 mr-1" />
                    12 Highlights
                  </Button>
                </CardFooter>
              </Card>

              <Card className="border-purple-100">
                <CardContent className="p-3">
                  <div className="w-full h-32 bg-gray-100 rounded-md mb-3 overflow-hidden">
                    <img
                      src="/placeholder.svg?height=128&width=180"
                      alt="Book cover"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-medium text-gray-900 text-sm">Deep Work</h3>
                  <p className="text-xs text-gray-500">Cal Newport</p>
                  <div className="flex items-center mt-1">
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`h-3 w-3 ${star <= 5 ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500 ml-1">5.0</span>
                  </div>
                </CardContent>
                <CardFooter className="p-3 pt-0">
                  <Button size="sm" variant="outline" className="w-full text-xs">
                    <Quote className="h-3 w-3 mr-1" />
                    18 Highlights
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="quotes" className="mt-4 space-y-4">
            <div className="bg-white p-4 rounded-lg border border-purple-100 mb-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <BookMarked className="h-5 w-5 text-purple-800 mr-2" />
                  <h3 className="font-medium text-gray-900">Favorite Quotes</h3>
                </div>
                <Button variant="outline" size="sm" className="text-xs">
                  <BookText className="h-3 w-3 mr-1" />
                  By Book
                </Button>
              </div>
              <Input
                placeholder="Search quotes..."
                className="mb-3 bg-gray-50 border-gray-200 focus-visible:ring-purple-800"
              />
              <div className="space-y-4">
                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <p className="text-gray-800 italic">
                      "Habits are the compound interest of self-improvement. The same way that money multiplies through
                      compound interest, the effects of your habits multiply as you repeat them."
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div>
                        <p className="text-sm font-medium">Atomic Habits</p>
                        <p className="text-xs text-gray-500">James Clear</p>
                      </div>
                      <Badge className="bg-purple-100 text-purple-800">Productivity</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <p className="text-gray-800 italic">
                      "The ability to perform deep work is becoming increasingly rare at exactly the same time it is
                      becoming increasingly valuable in our economy."
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div>
                        <p className="text-sm font-medium">Deep Work</p>
                        <p className="text-xs text-gray-500">Cal Newport</p>
                      </div>
                      <Badge className="bg-purple-100 text-purple-800">Focus</Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <p className="text-gray-800 italic">
                      "Realize deeply that the present moment is all you ever have. Make the Now the primary focus of
                      your life."
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div>
                        <p className="text-sm font-medium">The Power of Now</p>
                        <p className="text-xs text-gray-500">Eckhart Tolle</p>
                      </div>
                      <Badge className="bg-purple-100 text-purple-800">Mindfulness</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="recommended" className="mt-4">
            <Card className="border-purple-100 mb-4">
              <CardContent className="p-4">
                <h3 className="font-medium text-gray-900 mb-3">AI-Recommended Books</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Based on your reading history and preferences, Soma AI suggests these books for you:
                </p>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-16 h-24 bg-gray-100 rounded-md flex-shrink-0 overflow-hidden">
                      <img
                        src="/placeholder.svg?height=96&width=64"
                        alt="Book cover"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">Mindset: The New Psychology of Success</h4>
                      <p className="text-sm text-gray-500">Carol S. Dweck</p>
                      <p className="text-xs text-gray-600 mt-1">
                        Recommended because you enjoyed "Atomic Habits" and are interested in personal development.
                      </p>
                      <div className="mt-2 flex gap-2">
                        <Button size="sm" className="text-xs bg-purple-800 hover:bg-purple-900">
                          <Plus className="h-3 w-3 mr-1" />
                          Add to Library
                        </Button>
                        <Button size="sm" variant="outline" className="text-xs">
                          <Download className="h-3 w-3 mr-1" />
                          Preview
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <div className="w-16 h-24 bg-gray-100 rounded-md flex-shrink-0 overflow-hidden">
                      <img
                        src="/placeholder.svg?height=96&width=64"
                        alt="Book cover"
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">Why We Sleep</h4>
                      <p className="text-sm text-gray-500">Matthew Walker</p>
                      <p className="text-xs text-gray-600 mt-1">
                        Recommended based on your interest in wellness and productivity optimization.
                      </p>
                      <div className="mt-2 flex gap-2">
                        <Button size="sm" className="text-xs bg-purple-800 hover:bg-purple-900">
                          <Plus className="h-3 w-3 mr-1" />
                          Add to Library
                        </Button>
                        <Button size="sm" variant="outline" className="text-xs">
                          <Download className="h-3 w-3 mr-1" />
                          Preview
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button className="w-full bg-purple-800 hover:bg-purple-900">
              <BookOpen className="h-4 w-4 mr-2" />
              Get More Personalized Recommendations
            </Button>
          </TabsContent>
        </Tabs>
      </main>

      <nav className="sticky bottom-0 border-t bg-white">
        <div className="container flex items-center justify-between px-4 py-2">
          <Link href="/" className="flex flex-col items-center p-2 text-gray-500">
            <HomeIcon className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/calendar" className="flex flex-col items-center p-2 text-gray-500">
            <CalendarIcon className="h-5 w-5" />
            <span className="text-xs">Calendar</span>
          </Link>
          <Link href="/assistant" className="flex flex-col items-center p-2 text-gray-500">
            <Brain className="h-5 w-5" />
            <span className="text-xs">Soma AI</span>
          </Link>
          <Link href="/bookshelf" className="flex flex-col items-center p-2 text-purple-800">
            <BookOpen className="h-5 w-5" />
            <span className="text-xs">Bookshelf</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center p-2 text-gray-500">
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

function HomeIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}

function CalendarIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
      <line x1="16" x2="16" y1="2" y2="6" />
      <line x1="8" x2="8" y1="2" y2="6" />
      <line x1="3" x2="21" y1="10" y2="10" />
    </svg>
  )
}

function User(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="12" cy="8" r="5" />
      <path d="M20 21a8 8 0 1 0-16 0" />
    </svg>
  )
}
