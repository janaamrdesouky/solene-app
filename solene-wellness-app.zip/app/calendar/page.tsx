import {
  ArrowLeft,
  CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Plus,
  Brain,
  Clock,
  Settings,
  RefreshCw,
  CheckCircle,
  User,
} from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function CalendarPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <Link href="/" className="mr-4">
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Calendar</h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm">
              <Settings className="h-4 w-4 mr-2" />
              Sync
            </Button>
            <Button className="bg-purple-800 hover:bg-purple-900" size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <section className="mb-6">
          <Card className="border-purple-100 overflow-hidden">
            <div className="bg-gradient-to-r from-purple-700 to-purple-900 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="font-semibold text-xl">Calendar Integration</h2>
                  <p className="text-white/80 text-sm">Connect and optimize your schedule</p>
                </div>
                <Badge className="bg-white/20 text-white">Not Connected</Badge>
              </div>
              <p className="text-sm text-white/80 mb-4">
                Connect your Google or Apple Calendar to view and optimize your schedule with Soma AI.
              </p>
              <div className="flex gap-2">
                <Button className="bg-white text-purple-900 hover:bg-white/90">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  Connect Google Calendar
                </Button>
                <Button variant="outline" className="text-white border-white/30 hover:bg-white/10">
                  <CalendarIcon className="h-4 w-4 mr-2" />
                  Connect Apple Calendar
                </Button>
              </div>
            </div>
          </Card>
        </section>

        <section className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" className="h-8 w-8">
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <h2 className="text-lg font-semibold">April 2025</h2>
              <Button variant="outline" size="icon" className="h-8 w-8">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <Badge className="bg-purple-800">Follicular Phase</Badge>
          </div>

          <div className="grid grid-cols-7 gap-1 mb-4">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <div key={day} className="text-center text-sm font-medium text-gray-500 py-2">
                {day}
              </div>
            ))}
            {[...Array(30)].map((_, i) => {
              const day = i + 1
              const isToday = day === 14
              const hasEvents = [3, 7, 12, 14, 18, 21, 25].includes(day)
              return (
                <div
                  key={i}
                  className={`aspect-square flex flex-col items-center justify-center rounded-md text-sm ${
                    isToday
                      ? "bg-purple-800 text-white"
                      : hasEvents
                        ? "bg-purple-100 text-gray-900"
                        : "bg-white border border-gray-200 text-gray-600"
                  }`}
                >
                  <span>{day}</span>
                  {hasEvents && !isToday && <div className="w-1 h-1 bg-purple-800 rounded-full mt-1"></div>}
                </div>
              )
            })}
          </div>
        </section>

        <section>
          <Tabs defaultValue="today" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-purple-50">
              <TabsTrigger value="today" className="data-[state=active]:bg-white">
                Today
              </TabsTrigger>
              <TabsTrigger value="upcoming" className="data-[state=active]:bg-white">
                Upcoming
              </TabsTrigger>
              <TabsTrigger value="optimize" className="data-[state=active]:bg-white">
                Optimize
              </TabsTrigger>
            </TabsList>

            <TabsContent value="today" className="mt-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-gray-900">April 14, 2025</h3>
                  <Badge variant="outline" className="text-purple-800 border-purple-800">
                    Today
                  </Badge>
                </div>

                <div className="space-y-3">
                  <div className="flex items-start gap-3 border-l-2 border-purple-800 pl-3">
                    <div className="text-right min-w-[60px]">
                      <span className="text-sm font-medium">8:00 AM</span>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-md flex-1">
                      <div className="flex items-center">
                        <Clock className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Morning Routine</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Hydration, light stretching, breakfast</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 border-l-2 border-gray-200 pl-3">
                    <div className="text-right min-w-[60px]">
                      <span className="text-sm font-medium">10:00 AM</span>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-md flex-1">
                      <div className="flex items-center">
                        <Brain className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Creative Work</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">High energy time - ideal for complex tasks</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 border-l-2 border-gray-200 pl-3">
                    <div className="text-right min-w-[60px]">
                      <span className="text-sm font-medium">2:00 PM</span>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-md flex-1">
                      <div className="flex items-center">
                        <CalendarIcon className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Biology Study Session</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Focus on chapters 7-9 for upcoming exam</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 border-l-2 border-gray-200 pl-3">
                    <div className="text-right min-w-[60px]">
                      <span className="text-sm font-medium">7:00 PM</span>
                    </div>
                    <div className="bg-purple-50 p-3 rounded-md flex-1">
                      <div className="flex items-center">
                        <CalendarIcon className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Evening Skincare Ritual</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">Cleanse, tone, serum, moisturize</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="upcoming" className="mt-4">
              <div className="space-y-4">
                <Card className="border-purple-100">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-medium text-gray-900">Upcoming Events</h3>
                      <Badge variant="outline">Next 7 Days</Badge>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-start gap-3">
                        <div className="min-w-[80px] text-sm">
                          <div className="font-medium">Apr 15</div>
                          <div className="text-gray-500">Tomorrow</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-md flex-1">
                          <div className="flex items-center">
                            <CalendarIcon className="h-4 w-4 text-purple-800 mr-2" />
                            <span className="font-medium">Team Meeting</span>
                          </div>
                          <p className="text-xs text-gray-600 mt-1">10:00 AM - 11:30 AM</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <div className="min-w-[80px] text-sm">
                          <div className="font-medium">Apr 17</div>
                          <div className="text-gray-500">Thursday</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-md flex-1">
                          <div className="flex items-center">
                            <CalendarIcon className="h-4 w-4 text-purple-800 mr-2" />
                            <span className="font-medium">Biology Exam</span>
                          </div>
                          <p className="text-xs text-gray-600 mt-1">2:00 PM - 4:00 PM</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <div className="min-w-[80px] text-sm">
                          <div className="font-medium">Apr 20</div>
                          <div className="text-gray-500">Sunday</div>
                        </div>
                        <div className="bg-gray-50 p-3 rounded-md flex-1">
                          <div className="flex items-center">
                            <CalendarIcon className="h-4 w-4 text-purple-800 mr-2" />
                            <span className="font-medium">Yoga Class</span>
                          </div>
                          <p className="text-xs text-gray-600 mt-1">9:00 AM - 10:00 AM</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter className="px-4 py-3 bg-gray-50">
                    <Button className="w-full bg-purple-800 hover:bg-purple-900">
                      <CalendarIcon className="h-4 w-4 mr-2" />
                      View Full Calendar
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="optimize" className="mt-4">
              <Card className="border-purple-100 mb-4">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium text-gray-900">Calendar Optimization</h3>
                    <Badge className="bg-purple-800">AI Powered</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Let Soma AI analyze and optimize your schedule based on your energy levels, hormonal phase, and
                    priorities.
                  </p>

                  <div className="space-y-3">
                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Schedule high-focus tasks during energy peaks</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Soma will identify your optimal focus times based on your cycle and habits
                      </p>
                    </div>

                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Balance work and rest periods</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Automatically schedule breaks to maintain productivity and prevent burnout
                      </p>
                    </div>

                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-purple-800 mr-2" />
                        <span className="font-medium">Prioritize tasks based on deadlines and importance</span>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Soma will help you focus on what matters most at the right time
                      </p>
                    </div>
                  </div>

                  <div className="mt-4">
                    <Button className="w-full bg-purple-800 hover:bg-purple-900">
                      <RefreshCw className="h-4 w-4 mr-2" />
                      Optimize My Calendar
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-100">
                <CardContent className="p-4">
                  <h3 className="font-medium text-gray-900 mb-3">Connect Your Calendar</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    To optimize your schedule, first connect your preferred calendar service:
                  </p>

                  <div className="space-y-3">
                    <Button className="w-full justify-start">
                      <img src="/placeholder.svg?height=24&width=24" alt="Google Calendar" className="h-6 w-6 mr-2" />
                      Connect Google Calendar
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <img src="/placeholder.svg?height=24&width=24" alt="Apple Calendar" className="h-6 w-6 mr-2" />
                      Connect Apple Calendar
                    </Button>
                    <Button className="w-full justify-start" variant="outline">
                      <img src="/placeholder.svg?height=24&width=24" alt="Outlook Calendar" className="h-6 w-6 mr-2" />
                      Connect Outlook Calendar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <nav className="sticky bottom-0 border-t bg-white">
        <div className="container flex items-center justify-between px-4 py-2">
          <Link href="/" className="flex flex-col items-center p-2 text-gray-500">
            <HomeIcon className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/calendar" className="flex flex-col items-center p-2 text-purple-800">
            <CalendarIcon className="h-5 w-5" />
            <span className="text-xs">Calendar</span>
          </Link>
          <Link href="/assistant" className="flex flex-col items-center p-2 text-gray-500">
            <Brain className="h-5 w-5" />
            <span className="text-xs">Soma AI</span>
          </Link>
          <Link href="/challenges" className="flex flex-col items-center p-2 text-gray-500">
            <Activity className="h-5 w-5" />
            <span className="text-xs">Challenges</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center p-2 text-gray-500">
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

function HomeIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}

function Activity(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </svg>
  )
}
