import { ArrowLeft, Play, Pause, SkipBack, SkipForward, Music, Headphones, Radio, List, Plus } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Brain, User } from "lucide-react"

export default function MusicPage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <Link href="/" className="mr-4">
              <ArrowLeft className="h-5 w-5 text-gray-600" />
            </Link>
            <h1 className="text-lg font-semibold text-gray-900">Music Integration</h1>
          </div>
          <Button variant="outline" size="sm">
            <Plus className="h-4 w-4 mr-2" />
            Connect Service
          </Button>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <section className="mb-6">
          <Card className="border-purple-100 overflow-hidden">
            <div className="bg-gradient-to-r from-purple-700 to-purple-900 p-6 text-white">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Avatar className="h-12 w-12 border-2 border-white">
                    <AvatarImage src="/placeholder.svg?height=48&width=48" alt="Music service" />
                    <AvatarFallback className="bg-purple-400 text-white">
                      <Music className="h-6 w-6" />
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="font-semibold text-xl">Music Integration</h2>
                    <p className="text-white/80 text-sm">Sync with Spotify or Apple Music</p>
                  </div>
                </div>
                <Badge className="bg-white/20 text-white">Connected</Badge>
              </div>
              <p className="text-sm text-white/80 mb-4">
                Personalized playlists based on your mood, activity, and hormonal phase
              </p>
              <div className="flex gap-2">
                <Button className="bg-white text-purple-900 hover:bg-white/90">
                  <Headphones className="h-4 w-4 mr-2" />
                  Open Spotify
                </Button>
                <Button variant="outline" className="text-white border-white/30 hover:bg-white/10">
                  <Radio className="h-4 w-4 mr-2" />
                  Manage Connection
                </Button>
              </div>
            </div>
          </Card>
        </section>

        <section className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Now Playing</h2>
            <Badge className="bg-purple-100 text-purple-800">Follicular Phase</Badge>
          </div>

          <Card className="border-purple-100 mb-4">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-gray-100 rounded-md flex-shrink-0 overflow-hidden">
                  <img
                    src="/placeholder.svg?height=64&width=64"
                    alt="Album cover"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900">Focus Flow</h3>
                  <p className="text-sm text-gray-500">Deep focus playlist for productive work</p>
                  <div className="flex items-center gap-4 mt-3">
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-full">
                      <SkipBack className="h-4 w-4" />
                    </Button>
                    <Button className="h-10 w-10 rounded-full bg-purple-800 hover:bg-purple-900">
                      <Pause className="h-5 w-5" />
                    </Button>
                    <Button variant="outline" size="icon" className="h-8 w-8 rounded-full">
                      <SkipForward className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        <section>
          <Tabs defaultValue="mood" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-purple-50">
              <TabsTrigger value="mood" className="data-[state=active]:bg-white">
                By Mood
              </TabsTrigger>
              <TabsTrigger value="activity" className="data-[state=active]:bg-white">
                By Activity
              </TabsTrigger>
              <TabsTrigger value="phase" className="data-[state=active]:bg-white">
                By Phase
              </TabsTrigger>
            </TabsList>

            <TabsContent value="mood" className="mt-4">
              <div className="grid grid-cols-2 gap-4">
                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <div className="w-full h-32 bg-gradient-to-br from-blue-400 to-purple-600 rounded-md mb-3 flex items-center justify-center">
                      <Music className="h-10 w-10 text-white" />
                    </div>
                    <h3 className="font-medium text-gray-900">Calm & Relaxed</h3>
                    <p className="text-xs text-gray-500 mt-1">Gentle ambient sounds to soothe your mind</p>
                  </CardContent>
                  <CardFooter className="p-3 pt-0">
                    <Button size="sm" className="w-full bg-purple-800 hover:bg-purple-900">
                      <Play className="h-3 w-3 mr-1" />
                      Play Now
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <div className="w-full h-32 bg-gradient-to-br from-pink-400 to-red-500 rounded-md mb-3 flex items-center justify-center">
                      <Music className="h-10 w-10 text-white" />
                    </div>
                    <h3 className="font-medium text-gray-900">Energized & Motivated</h3>
                    <p className="text-xs text-gray-500 mt-1">Upbeat tracks to boost your energy</p>
                  </CardContent>
                  <CardFooter className="p-3 pt-0">
                    <Button size="sm" className="w-full bg-purple-800 hover:bg-purple-900">
                      <Play className="h-3 w-3 mr-1" />
                      Play Now
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <div className="w-full h-32 bg-gradient-to-br from-green-400 to-teal-500 rounded-md mb-3 flex items-center justify-center">
                      <Music className="h-10 w-10 text-white" />
                    </div>
                    <h3 className="font-medium text-gray-900">Focused & Productive</h3>
                    <p className="text-xs text-gray-500 mt-1">Concentration-enhancing instrumental music</p>
                  </CardContent>
                  <CardFooter className="p-3 pt-0">
                    <Button size="sm" className="w-full bg-purple-800 hover:bg-purple-900">
                      <Play className="h-3 w-3 mr-1" />
                      Play Now
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-3">
                    <div className="w-full h-32 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-md mb-3 flex items-center justify-center">
                      <Music className="h-10 w-10 text-white" />
                    </div>
                    <h3 className="font-medium text-gray-900">Reflective & Introspective</h3>
                    <p className="text-xs text-gray-500 mt-1">Thoughtful melodies for journaling and reflection</p>
                  </CardContent>
                  <CardFooter className="p-3 pt-0">
                    <Button size="sm" className="w-full bg-purple-800 hover:bg-purple-900">
                      <Play className="h-3 w-3 mr-1" />
                      Play Now
                    </Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="activity" className="mt-4">
              <div className="space-y-3">
                <Card className="border-purple-100">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg text-purple-800">
                        <Headphones className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Study Session</h3>
                        <p className="text-sm text-gray-500">Focus-enhancing music for deep learning</p>
                      </div>
                      <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                        <Play className="h-3 w-3 mr-1" />
                        Play
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg text-purple-800">
                        <Headphones className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Skincare Ritual</h3>
                        <p className="text-sm text-gray-500">Calming sounds for your self-care routine</p>
                      </div>
                      <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                        <Play className="h-3 w-3 mr-1" />
                        Play
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg text-purple-800">
                        <Headphones className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Workout Energy</h3>
                        <p className="text-sm text-gray-500">High-energy tracks for exercise</p>
                      </div>
                      <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                        <Play className="h-3 w-3 mr-1" />
                        Play
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-purple-100">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-purple-100 p-2 rounded-lg text-purple-800">
                        <Headphones className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Sleep & Relaxation</h3>
                        <p className="text-sm text-gray-500">Gentle sounds for winding down</p>
                      </div>
                      <Button size="sm" className="bg-purple-800 hover:bg-purple-900">
                        <Play className="h-3 w-3 mr-1" />
                        Play
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="phase" className="mt-4">
              <Card className="border-purple-100 mb-4">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-medium text-gray-900">Cycle-Aware Playlists</h3>
                    <Badge className="bg-purple-800">Follicular Phase</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">
                    Music recommendations optimized for your current hormonal phase to support your energy levels and
                    mood.
                  </p>

                  <div className="space-y-3">
                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Music className="h-4 w-4 text-purple-800" />
                          <span className="font-medium">Creative Flow</span>
                        </div>
                        <Button size="sm" className="h-7 bg-purple-800 hover:bg-purple-900">
                          <Play className="h-3 w-3 mr-1" />
                          Play
                        </Button>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Upbeat but not overwhelming tracks to support your rising energy
                      </p>
                    </div>

                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Music className="h-4 w-4 text-purple-800" />
                          <span className="font-medium">Productivity Boost</span>
                        </div>
                        <Button size="sm" className="h-7 bg-purple-800 hover:bg-purple-900">
                          <Play className="h-3 w-3 mr-1" />
                          Play
                        </Button>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Rhythmic instrumental tracks to enhance your natural focus
                      </p>
                    </div>

                    <div className="bg-purple-50 p-3 rounded-md">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Music className="h-4 w-4 text-purple-800" />
                          <span className="font-medium">Social Energy</span>
                        </div>
                        <Button size="sm" className="h-7 bg-purple-800 hover:bg-purple-900">
                          <Play className="h-3 w-3 mr-1" />
                          Play
                        </Button>
                      </div>
                      <p className="text-xs text-gray-600 mt-1">
                        Uplifting tracks that complement your increased social energy
                      </p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="px-4 py-3 bg-gray-50">
                  <Button className="w-full bg-purple-800 hover:bg-purple-900">
                    <List className="h-4 w-4 mr-2" />
                    View All Phase Playlists
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </main>

      <nav className="sticky bottom-0 border-t bg-white">
        <div className="container flex items-center justify-between px-4 py-2">
          <Link href="/" className="flex flex-col items-center p-2 text-gray-500">
            <HomeIcon className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/calendar" className="flex flex-col items-center p-2 text-gray-500">
            <CalendarIcon className="h-5 w-5" />
            <span className="text-xs">Calendar</span>
          </Link>
          <Link href="/assistant" className="flex flex-col items-center p-2 text-gray-500">
            <Brain className="h-5 w-5" />
            <span className="text-xs">Soma AI</span>
          </Link>
          <Link href="/music" className="flex flex-col items-center p-2 text-purple-800">
            <Music className="h-5 w-5" />
            <span className="text-xs">Music</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center p-2 text-gray-500">
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

function HomeIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}

function CalendarIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
      <line x1="16" x2="16" y1="2" y2="6" />
      <line x1="8" x2="8" y1="2" y2="6" />
      <line x1="3" x2="21" y1="10" y2="10" />
    </svg>
  )
}
