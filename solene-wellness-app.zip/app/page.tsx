import Link from "next/link"
import { MoonStar, Sun, Calendar, BookOpen, Brain, Heart, Activity, User } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-purple-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center justify-between h-16 px-4">
          <div className="flex items-center">
            <img src="/images/logo.png" alt="Solene" className="h-10 w-10 rounded-lg mr-2" />
            <h1 className="text-2xl font-semibold text-purple-900">Solene</h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-purple-800">
              <MoonStar className="h-5 w-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
              <AvatarFallback className="bg-purple-200 text-purple-900">JD</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-2xl font-semibold text-gray-900">Good morning, Jane</h2>
              <p className="text-gray-600">Your day is aligned with your follicular phase</p>
            </div>
            <Button className="bg-purple-800 hover:bg-purple-900">
              <Sun className="mr-2 h-4 w-4" />
              Morning Call
            </Button>
          </div>

          <Card className="mb-6 border-purple-100 bg-white/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-gray-900">Today's Progress</h3>
                <span className="text-sm text-purple-800 font-medium">3/5 completed</span>
              </div>
              <Progress value={60} className="h-2 bg-purple-100" indicatorClassName="bg-purple-700" />
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 mt-4">
                <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-purple-100">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-1">
                    <Activity className="h-4 w-4" />
                  </div>
                  <span className="text-xs text-gray-600">Workout</span>
                  <span className="text-xs font-medium text-purple-800">Done</span>
                </div>
                <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-purple-100">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-1">
                    <BookOpen className="h-4 w-4" />
                  </div>
                  <span className="text-xs text-gray-600">Reading</span>
                  <span className="text-xs font-medium text-purple-800">Done</span>
                </div>
                <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-purple-100">
                  <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-1">
                    <Brain className="h-4 w-4" />
                  </div>
                  <span className="text-xs text-gray-600">Meditation</span>
                  <span className="text-xs font-medium text-purple-800">Done</span>
                </div>
                <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-gray-200">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mb-1">
                    <Heart className="h-4 w-4" />
                  </div>
                  <span className="text-xs text-gray-600">Skincare</span>
                  <span className="text-xs text-gray-400">7:00 PM</span>
                </div>
                <div className="flex flex-col items-center p-2 rounded-lg bg-white border border-gray-200">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 mb-1">
                    <User className="h-4 w-4" />
                  </div>
                  <span className="text-xs text-gray-600">Journal</span>
                  <span className="text-xs text-gray-400">9:00 PM</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="today" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-purple-50">
              <TabsTrigger value="today" className="data-[state=active]:bg-white">
                Today
              </TabsTrigger>
              <TabsTrigger value="schedule" className="data-[state=active]:bg-white">
                Schedule
              </TabsTrigger>
              <TabsTrigger value="insights" className="data-[state=active]:bg-white">
                Insights
              </TabsTrigger>
            </TabsList>
            <TabsContent value="today" className="mt-4">
              <div className="space-y-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="bg-purple-100 text-purple-800 p-2 rounded-lg">
                        <Calendar className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Study Session: Biology</h3>
                          <span className="text-sm text-gray-500">2:00 PM - 4:00 PM</span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">Focus on chapter 7-9 for upcoming exam</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Button variant="outline" size="sm" className="text-xs h-8">
                            Reschedule
                          </Button>
                          <Button size="sm" className="text-xs h-8 bg-purple-800 hover:bg-purple-900">
                            Start Session
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="bg-purple-100 text-purple-800 p-2 rounded-lg">
                        <Activity className="h-5 w-5" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">Evening Skincare Ritual</h3>
                          <span className="text-sm text-gray-500">7:00 PM</span>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">Cleanse, tone, serum, moisturize</p>
                        <div className="flex items-center gap-2 mt-2">
                          <Button variant="outline" size="sm" className="text-xs h-8">
                            Skip Today
                          </Button>
                          <Button size="sm" className="text-xs h-8 bg-purple-800 hover:bg-purple-900">
                            Start Guided Routine
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            <TabsContent value="schedule" className="mt-4">
              <div className="text-center py-8 text-gray-500">
                <Calendar className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                <h3 className="font-medium text-gray-700">Weekly Schedule View</h3>
                <p className="text-sm">Your upcoming activities and routines would appear here</p>
              </div>
            </TabsContent>
            <TabsContent value="insights" className="mt-4">
              <div className="text-center py-8 text-gray-500">
                <Brain className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                <h3 className="font-medium text-gray-700">Wellness Insights</h3>
                <p className="text-sm">Your progress analytics and cycle insights would appear here</p>
              </div>
            </TabsContent>
          </Tabs>
        </section>

        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Quick Access</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Link
              href="/assistant"
              className="flex flex-col items-center p-4 rounded-lg bg-white border border-purple-100 hover:border-purple-300 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-2">
                <Brain className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium text-gray-900">Soma AI</span>
              <span className="text-xs text-gray-500">Your personal assistant</span>
            </Link>
            <Link
              href="/challenges"
              className="flex flex-col items-center p-4 rounded-lg bg-white border border-purple-100 hover:border-purple-300 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-2">
                <Activity className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium text-gray-900">Challenges</span>
              <span className="text-xs text-gray-500">Custom programs</span>
            </Link>
            <Link
              href="/journal"
              className="flex flex-col items-center p-4 rounded-lg bg-white border border-purple-100 hover:border-purple-300 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-2">
                <BookOpen className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium text-gray-900">Journal</span>
              <span className="text-xs text-gray-500">Voice & text entries</span>
            </Link>
            <Link
              href="/bookshelf"
              className="flex flex-col items-center p-4 rounded-lg bg-white border border-purple-100 hover:border-purple-300 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-2">
                <BookOpen className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium text-gray-900">Bookshelf</span>
              <span className="text-xs text-gray-500">Reading & quotes</span>
            </Link>
            <Link
              href="/progress"
              className="flex flex-col items-center p-4 rounded-lg bg-white border border-purple-100 hover:border-purple-300 transition-colors"
            >
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center text-purple-800 mb-2">
                <Heart className="h-6 w-6" />
              </div>
              <span className="text-sm font-medium text-gray-900">Progress</span>
              <span className="text-xs text-gray-500">Photo archive & tracking</span>
            </Link>
          </div>
        </section>
      </main>

      <nav className="sticky bottom-0 border-t bg-white">
        <div className="container flex items-center justify-between px-4 py-2">
          <Link href="/" className="flex flex-col items-center p-2 text-purple-800">
            <HomeIcon className="h-5 w-5" />
            <span className="text-xs">Home</span>
          </Link>
          <Link href="/calendar" className="flex flex-col items-center p-2 text-gray-500">
            <Calendar className="h-5 w-5" />
            <span className="text-xs">Calendar</span>
          </Link>
          <Link href="/assistant" className="flex flex-col items-center p-2 text-gray-500">
            <Brain className="h-5 w-5" />
            <span className="text-xs">Soma AI</span>
          </Link>
          <Link href="/challenges" className="flex flex-col items-center p-2 text-gray-500">
            <Activity className="h-5 w-5" />
            <span className="text-xs">Challenges</span>
          </Link>
          <Link href="/profile" className="flex flex-col items-center p-2 text-gray-500">
            <User className="h-5 w-5" />
            <span className="text-xs">Profile</span>
          </Link>
        </div>
      </nav>
    </div>
  )
}

function HomeIcon(props) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <polyline points="9 22 9 12 15 12 15 22" />
    </svg>
  )
}
