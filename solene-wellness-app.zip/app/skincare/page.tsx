import { ArrowLeft, Play, Camera, Clock, Check, List } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function SkincarePage() {
  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-b from-rose-50 to-white">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm border-b">
        <div className="container flex items-center h-16 px-4">
          <Link href="/" className="mr-4">
            <ArrowLeft className="h-5 w-5 text-gray-600" />
          </Link>
          <h1 className="text-lg font-semibold text-gray-900">Skincare Ritual</h1>
        </div>
      </header>

      <main className="flex-1 container px-4 py-6">
        <section className="mb-8">
          <Card className="mb-6 border-rose-100 overflow-hidden">
            <div className="relative h-48 bg-gradient-to-r from-rose-300 to-rose-500">
              <div className="absolute inset-0 flex items-center justify-center">
                <Button size="lg" className="rounded-full bg-white/20 hover:bg-white/30 backdrop-blur-sm">
                  <Play className="h-6 w-6 text-white" />
                </Button>
              </div>
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/60 to-transparent text-white">
                <h2 className="font-semibold text-lg">Evening Skincare Ritual</h2>
                <p className="text-sm text-white/80">7:00 PM • 10 minutes</p>
              </div>
            </div>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium text-gray-900">Today's Progress</h3>
                <span className="text-sm text-rose-600 font-medium">Step 0/5</span>
              </div>
              <Progress value={0} className="h-2 bg-rose-100" indicatorClassName="bg-rose-500" />
            </CardContent>
          </Card>

          <Tabs defaultValue="routine" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-rose-50">
              <TabsTrigger value="routine" className="data-[state=active]:bg-white">
                Routine
              </TabsTrigger>
              <TabsTrigger value="products" className="data-[state=active]:bg-white">
                Products
              </TabsTrigger>
              <TabsTrigger value="analysis" className="data-[state=active]:bg-white">
                Analysis
              </TabsTrigger>
            </TabsList>

            <TabsContent value="routine" className="mt-4 space-y-4">
              <Card className="border-rose-100">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 flex-shrink-0">
                      <span className="text-sm font-medium">1</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">Cleanse</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Gently wash your face with lukewarm water and cleanser
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Button variant="outline" size="sm" className="text-xs h-8">
                          <Clock className="h-3 w-3 mr-1" />
                          60 sec
                        </Button>
                        <Button size="sm" className="text-xs h-8 bg-rose-600 hover:bg-rose-700">
                          <Play className="h-3 w-3 mr-1" />
                          Start
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-rose-100">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 flex-shrink-0">
                      <span className="text-sm font-medium">2</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">Tone</h3>
                      <p className="text-sm text-gray-600 mt-1">Apply toner with a cotton pad or your fingertips</p>
                      <div className="flex items-center gap-2 mt-3">
                        <Button variant="outline" size="sm" className="text-xs h-8">
                          <Clock className="h-3 w-3 mr-1" />
                          30 sec
                        </Button>
                        <Button size="sm" className="text-xs h-8 bg-rose-600 hover:bg-rose-700">
                          <Play className="h-3 w-3 mr-1" />
                          Start
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-rose-100">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-400 flex-shrink-0">
                      <span className="text-sm font-medium">3</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-900">Serum</h3>
                      <p className="text-sm text-gray-600 mt-1">Apply hyaluronic acid serum to damp skin</p>
                      <div className="flex items-center gap-2 mt-3">
                        <Button variant="outline" size="sm" className="text-xs h-8">
                          <Clock className="h-3 w-3 mr-1" />
                          45 sec
                        </Button>
                        <Button size="sm" className="text-xs h-8 bg-rose-600 hover:bg-rose-700">
                          <Play className="h-3 w-3 mr-1" />
                          Start
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Button className="w-full bg-rose-600 hover:bg-rose-700">
                <Camera className="h-4 w-4 mr-2" />
                Take Progress Photo
              </Button>
            </TabsContent>

            <TabsContent value="products" className="mt-4">
              <div className="grid gap-4">
                <Card className="border-rose-100">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                        <img
                          src="/placeholder.svg?height=64&width=64"
                          alt="Cleanser"
                          className="h-12 w-12 object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Gentle Cleanser</h3>
                        <p className="text-sm text-gray-500">Morning & Evening</p>
                        <div className="flex items-center gap-1 mt-1">
                          <Check className="h-3 w-3 text-green-500" />
                          <span className="text-xs text-gray-500">Recommended for your skin type</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-rose-100">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-gray-100 rounded-lg flex items-center justify-center">
                        <img
                          src="/placeholder.svg?height=64&width=64"
                          alt="Serum"
                          className="h-12 w-12 object-contain"
                        />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-gray-900">Hyaluronic Acid Serum</h3>
                        <p className="text-sm text-gray-500">Morning & Evening</p>
                        <div className="flex items-center gap-1 mt-1">
                          <Check className="h-3 w-3 text-green-500" />
                          <span className="text-xs text-gray-500">Hydrating, plumping</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Button variant="outline" className="w-full">
                  <List className="h-4 w-4 mr-2" />
                  View All Products
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="analysis" className="mt-4">
              <div className="text-center py-8 text-gray-500">
                <Camera className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                <h3 className="font-medium text-gray-700">Skin Analysis</h3>
                <p className="text-sm mb-4">Take a photo to analyze your skin condition</p>
                <Button className="bg-rose-600 hover:bg-rose-700">
                  <Camera className="h-4 w-4 mr-2" />
                  Take Photo for Analysis
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </section>
      </main>
    </div>
  )
}
